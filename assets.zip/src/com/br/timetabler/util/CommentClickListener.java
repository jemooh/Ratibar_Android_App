package com.br.timetabler.util;

import com.br.timetabler.model.Comment;

public interface CommentClickListener {
	public void onCommentClicked(Comment comment);
}
