package com.br.timetabler.util;

import com.br.timetabler.model.School;


public interface UniversitySelectListener {

	public void onUniversitySelected(int uni);
}
