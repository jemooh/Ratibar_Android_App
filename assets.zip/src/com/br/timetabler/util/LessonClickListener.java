package com.br.timetabler.util;

import com.br.timetabler.model.Lesson;

public interface LessonClickListener {
	public void onLessonClicked(Lesson lesson);
}
