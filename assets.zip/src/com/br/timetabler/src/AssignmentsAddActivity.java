package com.br.timetabler.src;

public class AssignmentsAddActivity {

}
