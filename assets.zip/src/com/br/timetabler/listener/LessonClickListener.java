package com.br.timetabler.listener;

import com.br.timetabler.model.Lesson;

public interface LessonClickListener {
	public void onLessonClicked(Lesson lesson);
}
