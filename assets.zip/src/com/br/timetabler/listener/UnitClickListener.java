package com.br.timetabler.listener;

import com.br.timetabler.model.Unit;

public interface UnitClickListener {
	public void onUnitClicked(Unit unit);
}
