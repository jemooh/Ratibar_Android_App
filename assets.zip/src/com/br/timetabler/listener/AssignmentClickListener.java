package com.br.timetabler.listener;

import com.br.timetabler.model.Assignment;

public interface AssignmentClickListener {
	public void onAssignmentClicked(Assignment assignment);
}
