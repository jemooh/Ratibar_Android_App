package com.br.timetabler.listener;

import com.br.timetabler.model.Comment;

public interface CommentClickListener {
	public void onCommentClicked(Comment comment);
}
