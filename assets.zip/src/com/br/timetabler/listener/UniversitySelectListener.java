package com.br.timetabler.listener;

import com.br.timetabler.model.School;


public interface UniversitySelectListener {

	public void onUniversitySelected(int uni);
}
