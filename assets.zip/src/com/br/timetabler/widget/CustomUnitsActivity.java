package com.br.timetabler.widget;

public class CustomUnitsActivity {

}
